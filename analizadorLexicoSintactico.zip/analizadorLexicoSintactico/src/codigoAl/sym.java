/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigoAl;

/**
 *
 * @author Jennifer Ortiz
 */
public class sym {
    static int EOF;
    static int ERROR;
    static int identificador;
    static int numero;
    static int parentesisIzquierdo;
    static int parentesisDerecho;
    static int coma;
    static int punto;
    static int puntoyComa;
    static int dosPuntos;
    static int corcheteIzquierdo;
    static int corcheteDerecho;
    static int llaveIzquierda;
    static int llaveDerecha;
    static int menorQue;
    static int mayorQue;
    static int igual;
    static int entre;
    static int mas;
    static int menos;
    static int multiplo;
    static int If;
    static int Do;
    static int menoroIgualque;
    static int mayoroIgualque;
    static int diferenteIgualque;
    static int Int;
    static int For;
    static int Main;
    static int Null;
    static int Else;
    static int While;
}
