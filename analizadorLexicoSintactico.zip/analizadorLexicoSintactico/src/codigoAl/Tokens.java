/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigoAl;

/**
 *
 * @author Jennifer Ortiz
 */
public enum Tokens {
    Main,
    Int,
    If,
    Else,
    For,
    Do,
    Null,
    While,
    parentesisIzquierdo,
    parentesisDerecho,
    coma,
    punto,
    puntoyComa,
    dosPuntos,
    corcheteIzquierdo,
    corcheteDerecho,
    llaveIzquierda,
    llaveDerecha,
    saltoLinea,
    menorQue,
    mayorQue,
    diferenteIgualque,
    menoroIgualque,
    mayoroIgualque,
    igual,
    entre,
    mas,
    menos,
    multiplo,
    identificador,
    numero,
    ERROR
}
